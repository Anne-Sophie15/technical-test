#!C:\Python34_64\python.exe -u

import cgi, cgitb
import numpy
import csv
import json

form = cgi.FieldStorage()

top = form.getvalue('n')
top = int(top) #storing the value of n given by the user
list_top = []

error_flag = 0
#checking the value n
if top <= 0:
    error_flag = 1

#finding the top "n" airports

else:
    dtype = []
    value = []
    file_name = '../bin/data_bookings2.csv' # file used to do the exercise

    def remove_duplicate(list):
        new_list = []
        for element in list:
            if element in new_list:
                continue
            else:
                new_list.append(element)
        return new_list

    #create a structures matrix that has our data
    csv_reader = csv.reader(open(file_name, 'rt'), delimiter = '^')

    #create the data type
    list_data = list(csv_reader)

    for header in list_data[0]:
        dtype.append((header.strip(' '), 'S10'))

    #format the data
    for data in list_data[1::]:
        new_format = []
        for info in data:
            new_format.append(info.strip(' '))
        value.append(tuple(new_format))

    #create the matrix
    data_matrix = numpy.array(value, dtype=dtype)

    #determining the list of airports
    arr_port=data_matrix['arr_port']
    list_airp = remove_duplicate(arr_port)

    # associating the number of passenger to the airport
    nb_pass = {}
    for airport in list_airp:
        nb_pass[airport] = 0
        
    passenger = data_matrix['pax']
    for i, nb in enumerate(passenger):
        airp = arr_port[i]
        nb_pass[airp] = nb_pass[airp] + int(nb)
        
    #sorting the dictionary in a decreasing order
    ordered_airp = sorted(nb_pass, key=nb_pass.__getitem__, reverse = True)

    list_ordered = []
    for i, airp in enumerate(ordered_airp):
        text = airp.decode("utf-8")
        # in python 3 you need to transform byte literal into strings
        dico = {'rank': '{0}'.format(i+1),
                'name': '{0}'.format(text),
                'nb_pass': '{0}'.format(nb_pass[airp])}
        list_ordered.append(dico)
    
    if top > len(list_ordered):
        top = len(list_ordered)
    #create a string of that will be understood by json 
    list_top = json.dumps(list_ordered[0:top], separators=(',',': '))

print ("Content-type: text/html\n\n")
print ('<html>')
print ('<head>')
print ('<meta charset="utf-8" />')
print ('<link rel="stylesheet" href="/technical_test/style.css"/>')
print ('<title> Technical test </title>')
print ('</head>')

#Javascript Start
print('''
<script>
window.onload = function(){
var element = document.getElementById("container");
var ele_title = document.getElementById("title")
''')
print('var error_flag = {0};'.format(error_flag))
print ('var top = {0};'.format(top))

print ('if (error_flag === 1){')
print ('var title = "<h1> Error </h1>";')
print ('var text = \'<img src= "/technical_test/bin/img_error.png" alt="error" class="img_error"/><div></div>\';')
print('text += \'<div class = "error"> The value of n need to be an integer greater than 0. </div>\';')
print('}') 
print('else {')
print('var list_top = \'{0}\';'.format(list_top))
print ('''

var obj = JSON.parse(list_top);
var title = "<h1> Top " + top + " arrival airport </h1>"
var text = "<p><h1>The top " + obj.length + " airports are :</h1>";

for (i = 0; i < obj.length ; i++){
text +=  '&nbsp&nbsp&nbsp&nbsp' + (i+1) + ') ' + obj[i].name + 
           " with " + obj[i].nb_pass + " passengers. </br>";
}
text += "</br></p>";
}
element.innerHTML =  text;
ele_title.innerHTML = title;
}

</script>
''')
# End Javascript

#html page body
print ('''
<body>
  <div id="block_page">
    <header>
      <div id = "title"> </div>
      <h2> Results </h2>
    </header>
    <section>
    
      <div id = "container"> </div>
    
      <form action = "top_n_airp.py" methode = "post">
        <article>
          <h1> Number of airport </h1>
          <p class = "explaination"> Enter the number n to search the top "n" arrival airport. </br> "n" is an integer greater than 0.</p>
        </article>

        <div>
          <label for = "nb_max"> Enter the value of n: </label>
          <input type = "number" value = '{0}' name = "n" />
        </div>
        <div>
          <button type = "submit"> Search </button>
        </div>
      </form>

      
    </section>
    <footer>
      <h1> Copyrights 2016 Barthelet A-S SOME RIGHTS RESERVED </h1>
      <p> All results can be used freely, however the codes are under author protection.</p>
    </footer>
  </div>
</body>
'''.format(top,))
print('</html>')


    
